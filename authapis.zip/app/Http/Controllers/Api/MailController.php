<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Mail\SendMail;
use App\Models\Invitation;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Str;
class MailController extends Controller
{
    public function sendInvitations(Request $request)
    {   
        $request->validate([
            'email' => 'required',
        ]);

        $invitation = Invitation::where(['email' => $request->input('email')])->first();
        if($invitation){

        }else{
            $invitation = new Invitation;
            $invitation->email = $request->input('email');
        }       
        
        $random =  mt_rand(1000000000, 9999999999);
        $invitation->hash_no = Hash::make($random);
        $invitation->save();

        $sendmail = Mail::to($request->email)->send(new SendMail($invitation));

        if(empty($sendmail)) { 
            return response([
                'success' => 1,
                'message' => "Invitation mail sent successfully."
            ]);
        }else{ 
            return response([
                'success' => 0,
                'message'=>"Invitation sent failed, please try again."
            ]);
        }

    }

    public function signupForm(Request $request ,$hash)
    {        
        $hash = json_decode(base64_decode($hash),true);
        if(isset($hash['email']) && !empty($hash['email']) && isset($hash['hash_no']) && !empty($hash['hash_no'])){
            
            $data = $request->all();
            $data['email'] = $hash['email'];
            
            $validator = Validator::make($data, [
                'user_name' => 'required|min:4|max:20|unique:users',
                'password' => 'required',
                'email' => 'required|unique:users',
            ]);
            if ($validator->fails()) {
                // get first error message
                $error = $validator->errors()->first();
                return response([
                    'error'=>$error
                ]);
            }

            $check_link = Invitation::where('email','=',$data['email'])->where('hash_no','=',$hash['hash_no'])->first();
            if(empty($check_link)){
                return response([
                    'error'=>'Invalid invitation link'
                ]);
            }
        
            $data['verification_code'] = mt_rand(100000, 999999);
            Mail::send('api.verification_code', $data, function($message)use($data) {            
                $message->to($data['email'])
                    ->subject('Verification Code');
            });
            
            $user = new User;
            $user->verification_code = $data['verification_code'];
            $user->user_name = $request->input('user_name');
            $user->email = $data['email'];
            $user->password = Hash::make($request->input('password'));
            $user->remember_token = Str::random(60);
            $user->save();
            
            return response([
                'success' => ['Registration done successfully, We sent you verification code in your email to verify your account.']
            ]);
        }else{
            return response([
                'error' => 'Invalid invitation link'
            ]);
        }
        
    }

    public function verify_email(Request $request){
        $validator = Validator::make($request->all(), [
            'verification_code' => 'required',
            'email' => 'required',
        ]);
        if ($validator->fails()) {
            // get first error message
            $error = $validator->errors()->first();
            return response([
                'error'=>$error
            ]);
        }

        $user = User::where('email','=',$request->email)->first();
        if(empty($user)){
            return response([
                'error'=>"Invalid email"
            ]);
        }

        if(!empty($user->email_verified_at)){
            return response([
                'error'=>"Already email verified."
            ]);
        }

        if($user->verification_code != $request->verification_code){
            return response([
                'error'=>"Invalid verification code."
            ]);
        }

        $user->verification_code = null;
        $user->email_verified_at = date('Y-m-d H:i:s');
        $user->save();
        return response([
            'success' => ['Your email has been verified successfully.']
        ]);
    }
}
