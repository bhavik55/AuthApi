<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Mail\SendMail;
use App\Models\Invitation;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function profile(Request $request){
        $user = Auth::user();
        if($user){
            return response()->json(['success' => 1, 'user' => $user]);
        }
        return response()->json(['success' => 0, 'message' => "Invalid request"]);
    }

    public function update_profile(Request $request){
        
        $user_id = Auth::user()->id;
        $userData = $request->validate([
            'user_name' => 'required|unique:users,user_name,'.$user_id,
            'name' => 'required',
            'email' => 'required|unique:users,email,'.$user_id,
            'avatar' => 'image|mimes:jpeg,png,jpg|max:2048|dimensions:min_width=256,min_height=256,max_width=256,max_height=256',
        ], ['avatar.dimensions' => 'Avatar must 256px x 256px']);

        $user = User::where(['id' => $user_id])->first();
      
        $user->user_name = $request->user_name;
        $user->name = $request->name;
        $user->email = $request->email;
        if(isset($request->avatar)){
            $imageName = time().'.'.$request->avatar->extension();  
            $request->avatar->move(public_path('avatars'), $imageName);
            $user->avatar = $imageName;
        }
        $user->save();
        if(!empty($user->avatar)){
            $user->avatar = url('/avatars/'.$user->avatar);
        }
        return response()->json(['success' => 1, 'user' => $user]);
        
    }
}

?>