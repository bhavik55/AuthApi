<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Api\RegisterController;
use App\Http\Controllers\Api\MailController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/sendInvitations', [MailController::class, 'sendInvitations']);

Route::post('/form/{hash}', [MailController::class, 'signupForm'])->name('signupform.form');

Route::post('verify_email', [MailController::class, 'verify_email']);

// Route::post('register', [RegisterController::class, 'register']);
// Route::post('login', [RegisterController::class, 'login']);
// Route::post('/register', 'Api\AuthController@register');
Route::post('/login', [AuthController::class, 'login']);


// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

    

Route::middleware('auth:api')->group( function () {

    // Route::resource('profile', UserController::class);
    Route::post('/profile', [UserController::class, 'profile']);
    Route::post('/update_profile', [UserController::class, 'update_profile']);
    Route::post('/logout', [AuthController::class, 'logout']);

});

