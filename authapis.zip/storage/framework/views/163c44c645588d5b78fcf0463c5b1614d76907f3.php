<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invitation</title>


</head>
<body>
<div>
    <?php
        $email = $invitation->email;
        $hash_no = $invitation->hash_no;
    ?>
    <h2>Hello,</h2>
    <p>
        Please click below link to sign up.
    </p>
    
    <p><a href="<?php echo e(route('signupform.form',['hash' => base64_encode(json_encode(['email' => $email, 'hash_no' => $hash_no]))])); ?>"><?php echo e(route('signupform.form',['hash' => base64_encode(json_encode(['email' => $email, 'hash_no' => $hash_no]))])); ?></a></p>
</div>
</body>
</html><?php /**PATH E:\xampp\htdocs\apiproject\resources\views/api/invitation.blade.php ENDPATH**/ ?>